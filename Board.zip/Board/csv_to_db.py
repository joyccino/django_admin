import csv
import pandas as pd
from pandas import DataFrame
import pymysql
import my_settings

test = pd.read_csv('/Users/soobeenjmoon/Board/table/table_manager.csv')

DATABASES = my_settings.DATABASES



conn = pymysql.connect(host=DATABASES['default']['HOST'], port=DATABASES['default']['PORT'], user=DATABASES['default']['USER'],password=DATABASES['default']['PASSWORD'],db=DATABASES['default']['NAME'], charset='utf8')

cursor = conn.cursor()

sql = "SELECT client_key from classified_info where social = 'google'"

cursor.execute(sql)
    
data = cursor.fetchone()
print(len(data))

client_key = data[0]
