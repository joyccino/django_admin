from django.urls import path, include
from . import views
from django.conf.urls import include
from django.contrib import admin
from django.urls import path
from django.conf import settings

# Session test
urlpatterns = [
    path('signup/', views.signup, name='signup'),
    path('', views.login, name='login'),
    path('home/', views.home, name='home'),
    path('post/', views.post, name='post'),
    path('post/<int:id>', views.detail, name='detail'),
    path('main/', views.main, name='main'),
    path('main/main_detail/<str:message>', views.main_detail, name='main_detail'),
    path('admin/', admin.site.urls),
    path('google/', include('allauth.urls')),
    path('mypage/', views.mypage, name='mypage'),
    path('layout_edit/', views.layout_edit, name='layout_edit'),
    path('result/', views.result, name='result'),
]