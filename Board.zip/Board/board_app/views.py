from re import L
from django.http import HttpResponse, HttpResponseRedirect, Http404
from django.shortcuts import render, redirect, reverse
from .models import *
from django.urls import reverse
from django.contrib.auth.hashers import make_password, check_password #비밀번호 암호화 / 패스워드 체크(db에있는거와 일치성확인)
import csv
import pandas as pd
from pandas import DataFrame
from social_core.exceptions import AuthAlreadyAssociated 
from social_django.models import UserSocialAuth

from datetime import date
import my_settings
import json
import pymysql

pymysql.install_as_MySQLdb()

def result(request) :
    session_id = request.session.session_key
    request.session['test'] = '전달할 테스트 메세지'
    test = request.session['test']
    print('test ',test)
    contents = {
        'session_id': session_id,
        'test': test
    }
    return render(request, 'sessiontest.html', contents)
    
# def auth_allowed( backend, uid, user=None, *args, **kwargs): 
#     print("backend >>", backend) 
#     print("uid >> ", ) 
#     print("user >> ", user) 
#     print("args >> ", args) 
#     print("kwargs >> ", kwargs) 
    

#     return redirect('/main.html')

# Create your views here.
def index(request):
    boards = {'boards': Board.objects.all()}
    return render(request, 'list.html', boards)


def post(request):
    if request.method == "POST":
        author = request.POST['author']
        title = request.POST['title']
        content = request.POST['content']

        board = Board(author=author, title=title, content=content)
        board.save()
        return HttpResponseRedirect(reverse('home'))
    else:
        print('post requested ************************')
        return render(request, 'post.html')
    
def layout_edit(request) :
    # if request.method == "POST":
    #     author = request.POST['author']
    #     title = request.POST['title']
    #     content = request.POST['content']
    #     board = Board(author=author, title=title, content=content)
    #     board.save()
    #     return HttpResponseRedirect(reverse('home'))
    # else:
    #     print('post requested ************************')
    print(request.method)
    
    return render(request, 'layout_edit.html')
    
    
def detail(request, id):
    try:
        board = Board.objects.get(pk=id)
    except Board.DoesNotExist:
        raise Http404("Does not exist!")
    return render(request, 'detail.html', {'board': board})


def signup(request):
    return render(request, 'signup.html')

def home(request):
    boards = {'boards': Board.objects.all()}
    return render(request, 'list.html', boards)

def login(request):
    # logged_in_users = SocialaccountSocialaccount.objects.all()
    # logged_in_users.delete()
    response_data = {}

    if request.method == "GET" :
        return render(request, 'login.html')

    elif request.method == "POST":
        login_username = request.POST.get('username', None)
        login_password = request.POST.get('password', None)


        if not (login_username and login_password):
            response_data['error']="아이디와 비밀번호를 모두 입력해주세요."
        else : 
            myuser = Onionscrew.objects.get(username=login_username) 
            #db에서 꺼내는 명령. Post로 받아온 username으로 , db의 username을 꺼내온다.
            if check_password(login_password, myuser.password):
                request.session['user'] = myuser.id 
                #세션도 딕셔너리 변수 사용과 똑같이 사용하면 된다.
                #세션 user라는 key에 방금 로그인한 id를 저장한것.
                return redirect('/')
            else:
                response_data['error'] = "비밀번호가 틀렸습니다."

        return render(request, 'login.html',response_data)
    
# def main(request):
#     boards = {'boards': Board.objects.all()}
    
#     category_info = pd.read_csv('/Users/soobeenjmoon/Board/tesla_table.csv')
    
#     table_no = category_info['table_no'].unique()
#     table_name = category_info['table_name'].unique()
#     detail_no = category_info['detail_no']
#     detail_total = category_info['detail_total']
#     detail_name = category_info['detail_name']
#     # table_info = {'table_info' :  }
#     # category = {'category': }
    
#     return render(request, 'tesla_main.html', {'category':zip(detail_no, detail_total, detail_name),"table_info":zip(table_no,table_name)})

def main(request):

    table_manager = pd.read_csv('/Users/soobeenjmoon/Board/table/table_manager.csv')
    table_no = table_manager['table_no']
    table_title = table_manager['table_title']
    table_path = table_manager['table_path']
    
    detail_처방전_승인_관리 = pd.read_csv('/Users/soobeenjmoon/Board/table/detail_처방전 승인 관리.csv')
    table_01_no = detail_처방전_승인_관리['detail_no']
    table_01_title = detail_처방전_승인_관리['detail_title'] 
    detail_대쉬보드_관리 = pd.read_csv('/Users/soobeenjmoon/Board/table/detail_대쉬보드 관리.csv')
    context = {'table_info': zip(table_no,table_title,table_path), 'detail_info':zip(table_01_no,table_01_title)}
    
    # Db에 존재하는 회원과 비교하기 위함
    
    # 방금 들어온 email address 알아내기
    
    # 위의 address 를 db 에서 조회
    
    # if exist, return render(request, 'tesla_main.html', context)
    
    # else, return redirect('/google/logout/')
    try : 
        print('testtest**********below')
        logged_in_users = pd.DataFrame(list(SocialaccountSocialaccount.objects.all().values()))
        # uidtest = UserSocialAuth.uid
        print('users ',logged_in_users)
        extra_data = logged_in_users.extra_data
        extra_data = json.loads(extra_data.values[0])
        user_email = extra_data['email']
        
        print(request.session.session_key)

        DATABASES = my_settings.DATABASES
        conn = pymysql.connect(host=DATABASES['default']['HOST'], port=DATABASES['default']['PORT'], user=DATABASES['default']['USER'],password=DATABASES['default']['PASSWORD'],db=DATABASES['default']['NAME'], charset='utf8')

        # cursor = conn.cursor()
        # # try : 
        # user_verification = "SELECT * from onionscrew where user_id = '{0}'".format(user_email)
        # print('query following')
        # print(user_verification)
        # cursor.execute(user_verification)
        # user_data_from_db = cursor.fetchone()
        # if user_data_from_db != None :
        return render(request, 'tesla_main.html')
            
    #     else :
    #         return redirect('/google/logout/' , {'error_flag':True})
    except :
        # return render(request, 'tesla_main.html', context)
        return render(request, 'tesla_main.html')
        # return redirect('/google/logout/' , {'error_flag':True})

        
    
def main_detail(request, message):
    boards = {'boards': Board.objects.all()}
    if request.method == 'GET' :
        print('*************GET**************')
        # message = request.GET.get('message')
        # print('message '+message)
        
        return render(request, "main_detail.html", {'message':message})

def mypage(request) :
    return render(request, 'mypage.html')
